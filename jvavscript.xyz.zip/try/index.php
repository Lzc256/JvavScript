<?php
header("location:https://www.lzcapp.cn");
?>